
export interface Project {
  id: number;
  title: string;
  description: string;
  image: string;
  date: string;
  technologies: string[];
  githubLink: string;
  demoLink?: string;
  paperLink?: string;
}

export const projects: Project[] = [
  {
    id: 1,
    title: "Aurora",
    description: "A full-stack e-commerce platform with secure payments and responsive design.",
    image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "July 2024",
    technologies: ["HTML", "React", "Tailwind CSS", "Python", "Docker", "Razorpay"],
    githubLink: "https://github.com",
    demoLink: "https://github.com"
  },
  {
    id: 2,
    title: "Smart Maps & Traffic Analytics",
    description: "Full-stack web application for traffic analysis with integrated Google Maps API and machine learning capabilities for data visualization and insights.",
    image: "https://images.unsplash.com/photo-1548345680-f5475ea5df84?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "April 2025",
    technologies: ["Flask", "SQLAlchemy", "Google Maps API", "Machine Learning", "Python"],
    githubLink: "https://github.com/Baladhithya/SmartMaps",
    demoLink: "https://github.com/Baladhithya/SmartMaps"
  }
];
