
export interface Award {
  id: number;
  title: string;
  description: string;
  details?: string;
  year: string;
}

export const awards: Award[] = [
  {
    id: 1,
    title: "National Winners – MoSPI All-India Hackathon 2025",
    description: "Winners in the prestigious nationwide hackathon \"Hack the Future 2025\" organized by the Ministry of Statistics and Programme Implementation (MoSPI), Government of India.",
    details: "Solution implemented at IIT Gandhinagar during March 2025, recognized for impactful implementation.",
    year: "2025"
  }
];
