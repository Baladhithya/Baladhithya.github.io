import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { personalInfo } from '@/data/personal-info';
import { scrollToSection } from '@/lib/utils';

export function HeroSection() {
  const [visible, setVisible] = useState(false);
  const [typingIndex, setTypingIndex] = useState(0);

  // Small delay so the splash-to-hero transition feels smooth
  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 120);
    return () => clearTimeout(t);
  }, []);

  // Start typing the title as soon as the section fades in
  useEffect(() => {
    if (!visible) return;
    const interval = setInterval(() => {
      setTypingIndex(prev => {
        if (prev < personalInfo.title.length) return prev + 1;
        clearInterval(interval);
        return prev;
      });
    }, 55);
    return () => clearInterval(interval);
  }, [visible]);

  return (
    <section id="hero" className="pt-16 md:pt-20 min-h-screen flex items-center bg-black relative overflow-hidden">
      {/* Subtle scanlines */}
      <div
        className="absolute inset-0 pointer-events-none z-10 opacity-20"
        style={{ backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(255,255,255,0.03) 3px, rgba(255,255,255,0.03) 4px)' }}
      />

      <div className="max-w-screen-lg mx-auto px-4 md:px-8 w-full relative z-20">

        {/* Session info line — replaces the boot block, feels like a continuation */}
        <div
          className={`mb-10 font-mono text-xs text-white/30 flex items-center gap-3 transition-all duration-500 ${visible ? 'opacity-100' : 'opacity-0'}`}
        >
          <span style={{ color: 'var(--term-green)', opacity: 0.5 }}>●</span>
          <span>session active &nbsp;·&nbsp; /home/baladhithya/portfolio &nbsp;·&nbsp; type <span className="text-white/50">help</span> for commands</span>
        </div>

        {/* Prompt + name */}
        <div
          className={`mb-10 transition-all duration-600 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
          style={{ transitionDelay: '80ms' }}
        >
          <div className="font-mono text-sm mb-3" style={{ color: 'var(--term-green)', opacity: 0.65 }}>
            ~/portfolio $ whoami
          </div>

          <h1 className="text-3xl md:text-5xl font-bold text-white mb-3 tracking-tight">
            {personalInfo.name}
            <span
              className="inline-block w-[3px] h-8 md:h-12 ml-2 animate-blink align-middle"
              style={{ backgroundColor: 'var(--term-green)' }}
            />
          </h1>

          <div className="h-7 mb-5">
            <p className="font-mono text-white/70 text-base md:text-lg">
              <span style={{ color: 'var(--term-green)', opacity: 0.8 }}>{'> '}</span>
              {personalInfo.title.substring(0, typingIndex)}
              {typingIndex < personalInfo.title.length && <span className="animate-blink">|</span>}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-5 text-white/40 font-mono text-sm">
            <a
              href={`mailto:${personalInfo.email}`}
              className="hover:text-white/80 transition-colors flex items-center gap-1.5"
            >
              <i className="fas fa-envelope" style={{ color: 'var(--term-green)', opacity: 0.6 }} />
              {personalInfo.email}
            </a>
            <span className="flex items-center gap-1.5">
              <i className="fas fa-map-marker-alt" style={{ color: 'var(--term-green)', opacity: 0.6 }} />
              {personalInfo.location}
            </span>
          </div>
        </div>

        {/* Bio + actions */}
        <div
          className={`transition-all duration-600 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
          style={{ transitionDelay: '200ms' }}
        >
          <div className="font-mono text-sm mb-2" style={{ color: 'var(--term-green)', opacity: 0.65 }}>
            ~/portfolio $ cat bio.txt
          </div>

          <div className="border border-white/10 bg-white/[0.02] p-4 rounded font-mono text-white/70 text-sm leading-relaxed mb-6">
            {personalInfo.bio}
          </div>

          <div className="flex flex-wrap gap-3">
            <Button
              onClick={() => window.open('https://drive.google.com/file/d/1crWWrhY8QPe9xI_yYHkSHk3LikpqI9tc/view?usp=sharing', '_blank')}
              variant="outline"
              className="border-white/20 text-white/80 hover:bg-white hover:text-black hover:border-white transition-all font-mono text-sm"
            >
              $ ./download_resume.sh
            </Button>
            <Button
              onClick={() => scrollToSection('contact')}
              variant="outline"
              className="font-mono text-sm transition-all"
              style={{
                borderColor: 'var(--term-green-dim, rgba(0,255,65,0.35))',
                color: 'var(--term-green)',
              }}
            >
              $ ./contact.sh
            </Button>
          </div>
        </div>

        {/* Scroll indicator */}
        <div
          className={`mt-16 flex flex-col items-center gap-1 transition-all duration-600 ${visible ? 'opacity-100' : 'opacity-0'}`}
          style={{ transitionDelay: '400ms' }}
        >
          <span className="font-mono text-white/25 text-xs tracking-widest">$ cd ./about</span>
          <div className="animate-bounce-arrow flex flex-col items-center gap-0.5 mt-1">
            <div className="w-px h-5 bg-gradient-to-b from-transparent to-white/20" />
            <button
              onClick={() => scrollToSection('about')}
              className="text-white/25 transition-colors focus:outline-none"
              style={{ '--hover-color': 'var(--term-green)' } as any}
              onMouseEnter={e => (e.currentTarget.style.color = 'var(--term-green)')}
              onMouseLeave={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.25)')}
              aria-label="Scroll to about"
            >
              <svg width="16" height="10" viewBox="0 0 16 10" fill="none">
                <path d="M1 1L8 8L15 1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
